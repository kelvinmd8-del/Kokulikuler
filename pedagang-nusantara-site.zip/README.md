# Pedagang Nusantara - Game Edukasi

Game edukatif berbasis web yang mengenalkan konsep perbedaan harga barang antar pulau di Indonesia.

## Cara Menjalankan
1. Upload folder ini ke layanan hosting statis seperti:
   - GitHub Pages
   - Netlify Drop
   - Vercel
2. Pastikan file utama bernama **index.html**.
3. Setelah diunggah, game dapat dimainkan melalui browser web Anda.

Dibuat oleh **Kelvin, S.Pd.**
